<?php
class Curso {
    private $entrada;
    private $nome_curso;
    private $carga_horaria;
    private $categoria;
    private $pontos;

    public function setNome($nome_curso){
        $this->nome_curso = $nome_curso;
    }

    public function setCargaHoraria($carga_horaria){
        $this->carga_horaria = $carga_horaria;
    }

    public function setCategoria($categoria){
        $this->categoria = $categoria;
    }

    public function setPontos($pontos){
        $this->pontos = $pontos;
    }

    public function conecta() {
        $servidor = "localhost";
        $usuario = "root";
        $senha = "";
        $database = "certificados";

        $this->entrada = mysqli_connect($servidor, $usuario, $senha, $database);

        if (!$this->entrada) {
            echo "Erro ao conectar " . mysqli_connect_error();
        }

        return  $this->entrada;
    }

    public function inserirCurso() {

        $sql = "INSERT INTO cursos (nome_curso, carga_horaria, categoria, pontos) VALUES ('$this->nome_curso', $this->carga_horaria, '$this->categoria', $this->pontos)";
        
        
        if (mysqli_query($this->conecta(), $sql)) {
            $this->fecharConexao();
        } else {
            $this->fecharConexao();
            echo "Erro ao salvar os dados: " . mysqli_error($this->conecta());
            return false;
        }
    }
    public function RetornaDados(){
        $dados=mysqli_query($this->conecta(),"SELECT * FROM `cursos`");
        return $dados;
    }
    public function fecharConexao() {
        $this->conecta()->close();
    }

}
?>
