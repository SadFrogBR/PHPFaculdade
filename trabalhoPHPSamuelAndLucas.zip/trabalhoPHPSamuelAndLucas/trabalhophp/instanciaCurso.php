<?php
require_once('Curso.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome_curso = $_POST["nome_curso"];
    $carga_horaria = $_POST["carga_horaria"];
    $categoria = $_POST["categoria"];
    $pontos = $_POST["pontos"];

    $curso = new Curso();
    $curso->setNome($nome_curso);
    $curso->setCargaHoraria($carga_horaria);
    $curso->setCategoria($categoria);
    $curso->setPontos($pontos);
    $curso->inserirCurso();
    header("Location: index.html");
    exit;
} else {

}
?>
