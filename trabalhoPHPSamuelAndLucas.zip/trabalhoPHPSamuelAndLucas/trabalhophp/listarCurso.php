<?php
  include_once('curso.php');
  $curso = new Curso();
  $dados = $curso->RetornaDados();
  ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Cursos</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <!-- Barra de Navegação -->
    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <div class="container">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="listarCurso.php">Listar</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.html">Cadastro</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h1>Lista de Cursos</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Nome do Curso</th>
                    <th>Carga Horária</th>
                    <th>Categoria</th>
                    <th>Pontos</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dados as $key => $value) { ?>
                <tr>
                <td> <?php echo $value['nome_curso'] ?></td>
                <td> <?php echo $value['carga_horaria'] ?></td>
                <td> <?php echo $value['categoria'] ?></td>
                <td> <?php echo $value['pontos'] ?></td>
                </tr>
                <?php }?>
            </tbody>
        </table>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
