<?php

$conexao = conecta();
function conecta()
{
	$servidor="localhost";
	$usuario="root";
	$senha="";
	$database="samuel";
	$conexao=mysqli_connect($servidor,$usuario,$senha,$database);
	if(!$conexao){
		echo "Erro ao conectar ".mysqli_connect_error();
	}
	return $conexao;
}
?>