<?php 
	include_once 'conexao.php';
    session_start();

//echo "<br>O valor de CAMPO 2 é: " . $_POST["CPF"];
//echo "<br>O valor de CAMPO 2 é: " . $_POST["senha"];

 $CPF=$_POST["CPF"];
 $senha= $_POST["senha"];
$sql = "SELECT * FROM usuarios WHERE CPF = '$CPF' AND senha = '$senha'";
if ($result=mysqli_query($conexao,$sql )) {
    if ($result->num_rows == 1) {
        $row = mysqli_fetch_assoc($result);

            if($row['statusCarro']==1){
                // se caso o usuario tiver carro, buscar as informações 
  $sql ="SELECT usuarios.nome AS nome_usuario, usuarios.id, usuarios.idade, usuarios.CPF,usuarios.statusCarro , usuarios.periodo , carros.id AS carroID, carros.marca, carros.modelo, carros.ano, carros.vagasPreenchidas, carros.cor, carros.quantidadeLugares, carros.disponibilidade, carros.consumoKm
  FROM usuarios
  INNER JOIN carros ON usuarios.id = carros.usuario_id
  WHERE CPF = '$CPF' AND senha = '$senha'";

  
if ($result=mysqli_query($conexao,$sql )) {
    if ($result->num_rows == 1) {
        $row = mysqli_fetch_assoc($result);
     
      //  echo $row['id'];
      //  echo"<br>". $row['nome'];
     //   echo $row['CPF'];


    $_SESSION['id'] = $row['id'];
    $_SESSION['nome'] = $row['nome_usuario'];
    $_SESSION['idade'] =$row['idade'];;
    $_SESSION['CPF'] =$row['CPF'];
    $_SESSION['periodo'] = $row['periodo'];
    $_SESSION['statusCarro'] =  $row['statusCarro'];
    $_SESSION['carroID'] = $row['carroID'];
    $_SESSION['disponibilidade'] = $row['disponibilidade'];



        
      header("Location:../View/inicial.php");

       
    } else {
     echo"Senha incorreta";
     
    }


}



                
                
            }  else if($row['statusCarro']==0){

                $_SESSION['id'] = $row['id'];
                $_SESSION['nome'] = $row['nome'];
                $_SESSION['idade'] =$row['idade'];;
                $_SESSION['CPF'] =$row['CPF'];
                $_SESSION['periodo'] = $row['periodo'];
                $_SESSION['statusCarro'] = 0;
                $_SESSION['carroID'] = 0;
                $_SESSION['disponibilidade'] = 0;

                header("Location:../View/inicial.php");

            }


        
    } else{
        echo 'senha incorreta'; 
    }


}



//$sql = "SELECT * FROM usuarios WHERE CPF = '$CPF' AND senha = '$senha'";


?>