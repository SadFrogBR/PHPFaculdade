<?php 
	include_once 'conexao.php';
    session_start();

echo "O valor de CAMPO 1 é: " . $_POST["nome"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["idade"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["CPF"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["senha"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["periodo"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["statusCarro"];

	$nome=$_POST["nome"];
	$idade=$_POST["idade"];
	$CPF=$_POST["CPF"];
	$senha=$_POST["senha"];
	$periodo=$_POST["periodo"];
    $descricao=$_POST["descricao"];

    $statusCarro=$_POST["statusCarro"];



    if (mysqli_query($conexao, "INSERT INTO usuarios (nome, idade, CPF, senha, periodo,descricao, statusCarro) VALUES ('$nome', $idade, '$CPF', '$senha', '$periodo','$descricao', '$statusCarro');")) {

        $novo_id = mysqli_insert_id($conexao);
       // echo "Inserção bem-sucedida! O ID do novo registro é: $novo_id";
     $_SESSION['usuario_id'] = $novo_id;
  

        //sexo
        if($statusCarro==1){
           header("Location:../View/cadastroCarro.php");
        }
        else {
            header("Location:../View/login.html");

        }
    
    } else {
    }

   


 

?>