<?php 
include_once 'conexao.php';
session_start();

$id=$_SESSION['id'];
$nome=$_POST["nome"];
$idade=$_POST["idade"];
$CPF=$_POST["CPF"];
$senha=$_POST["senha"];
$periodo=$_POST["periodo"];
$descricao=$_POST["descricao"];

$query = "UPDATE usuarios SET nome = '$nome', idade = $idade, CPF = '$CPF', senha = '$senha', periodo = '$periodo', descricao = '$descricao' WHERE id = $id";

if (mysqli_query($conexao, $query)) {
    header("Location:../View/inicial.php");

}
?>