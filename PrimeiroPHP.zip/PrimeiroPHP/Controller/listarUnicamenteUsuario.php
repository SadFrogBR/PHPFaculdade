<?php 
include_once 'conexao.php';
$id=$_GET["id"];

$query = "SELECT * FROM `usuarios` WHERE id = $id";
$result = mysqli_query($conexao, $query);

if ($result) {
    $dados = mysqli_fetch_assoc($result);
    echo $dados['id'];
}

header("Location:../View/editarPessoas.php");

?>