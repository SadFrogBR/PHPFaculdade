<?php 
include_once 'conexao.php';
session_start();

echo "O valor de CAMPO 1 é: " . $_POST["marca"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["modelo"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["ano"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["cor"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["quantidadeLugares"];
echo "<br>O valor de CAMPO 2 é: " . $_POST["consumoKm"];


 $marca=$_POST["marca"];
 $modelo=$_POST["modelo"];
 $ano=$_POST["ano"];
 $cor=$_POST["cor"];
$quantidadeLugares=$_POST["quantidadeLugares"];
$consumoKm=$_POST["consumoKm"];
$id=$_SESSION['usuario_id'];
                    

if (mysqli_query($conexao, "INSERT INTO carros (marca, modelo, ano, cor, quantidadeLugares, consumoKm, usuario_id,disponibilidade,vagasPreenchidas) VALUES ('$marca', '$modelo', $ano, '$cor', '$quantidadeLugares', '$consumoKm', '$id',1,0);")) {
    header("Location:../View/login.html");
} else {
    echo "Erro ao salvar os dados: " . mysqli_error($conexao);
}

?>