<?php
include_once 'conexao.php';

$id=$_GET["id"];


$query = "SELECT * FROM usuarios WHERE id = $id;";
echo 'teste';
$dados=mysqli_query($conexao, $query);
if ($dadoss=mysqli_query($conexao, $query)) {

    $dadoss = mysqli_fetch_assoc($dados);
    echo 'teste';
    if($dadoss['statusCarro']==0) {
        $query = "DELETE FROM usuarios WHERE id = $id";
        mysqli_query($conexao, $query);
    }

    else if($dadoss['statusCarro']==1){
        echo $dadoss['statusCarro'];
        $query = "DELETE FROM carros WHERE usuario_id = $id";
        mysqli_query($conexao, $query);
        $query = "DELETE FROM usuarios WHERE id = $id";
        mysqli_query($conexao, $query);
        

    }

    header("Location:../View/login.html");

}

else {
    echo "Erro ao salvar os dados: " . mysqli_error($conexao);
}

?>