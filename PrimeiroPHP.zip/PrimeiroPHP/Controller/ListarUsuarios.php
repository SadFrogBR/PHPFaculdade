<?php
include_once 'conexao.php';
	$conexao=conecta();
	$dados=mysqli_query($conexao,"SELECT * FROM `usuarios`");

 //   header("Location:../View/listarUsuario.php");


?>