<?php 
include_once 'conexao.php';
session_start();

echo $id=$_GET["id"];


$query = "SELECT usuarios.nome AS nome_usuario, usuarios.idade, carros.marca, carros.modelo, carros.ano,carros.vagasPreenchidas, carros.cor, carros.quantidadeLugares, carros.disponibilidade, carros.consumoKm
  FROM usuarios
  INNER JOIN carros ON usuarios.id = carros.usuario_id
  WHERE carros.id = $id";


$dados = mysqli_query($conexao, $query);
$dados = mysqli_fetch_array($dados);
echo $dados['disponibilidade'];
if($dados['disponibilidade']==1){
    $query = "UPDATE carros SET disponibilidade = 0 WHERE id = $id";

   $_SESSION['disponibilidade']=0;

    $dados = mysqli_query($conexao, $query);
    header("Location:../View/inicial.php");


}

else if($dados['disponibilidade']==0){
    $query = "UPDATE carros SET disponibilidade = 1 WHERE id = $id";
    $dados = mysqli_query($conexao, $query);
    $query = "UPDATE carros SET vagasPreenchidas = 0 WHERE id = $id";
    $dados = mysqli_query($conexao, $query);

   $_SESSION['disponibilidade']=1;

    header("Location:../View/inicial.php");

}

?>