<?php 
include_once 'conexao.php';
session_start();

$id=$_GET["id"];


$query = "SELECT usuarios.nome AS nome_usuario, usuarios.idade, carros.marca, carros.modelo, carros.ano,carros.vagasPreenchidas, carros.cor, carros.quantidadeLugares, carros.disponibilidade, carros.consumoKm
  FROM usuarios
  INNER JOIN carros ON usuarios.id = carros.usuario_id
  WHERE carros.id = $id";
$dados = mysqli_query($conexao, $query);
$dados = mysqli_fetch_array($dados);


 $vagasPreenchidas=$dados['vagasPreenchidas'];
 $quantidadeLugares=$dados['quantidadeLugares'];

if($vagasPreenchidas < $quantidadeLugares) {
echo $vagasPreenchidas;
echo $quantidadeLugares;

  $vagasPreenchidas=$vagasPreenchidas+1;
  

$query = "UPDATE carros SET vagasPreenchidas =  $vagasPreenchidas WHERE id = $id";
mysqli_query($conexao, $query);
 header("Location:../View/inicial.php");

 if($vagasPreenchidas==$quantidadeLugares){
  $query = "UPDATE carros SET disponibilidade = 0 WHERE id = $id";
  mysqli_query($conexao, $query);
  $_SESSION['disponibilidade']=0;
 }
  
}
//caso bugar, vai bloquear mais gente de ir nesse carro ai;
else{
    $query = "UPDATE carros SET disponibilidade = 0 WHERE id = $id";
    mysqli_query($conexao, $query);
   

        header("Location:../View/inicial.php");


}




?>