<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="#">Rodízio de carona</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../View/inicial.php">Página Inicial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../view/bio.php">Sobre Nós</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/listarUsuario.php">Exibir Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../Controller/deslogar.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<div class="container mt-4">
    <h1 class="display-4">Rodizio de Caronas</h1>
    <p>
        Bem-vindo usuario do Rodízio de Carona. Aqui você pode conhecer um pouco mais sobre a nossa equipe e a missão da nossa plataforma.
    </p>
    <p>
        Nossa missão é conectar os alunos que desejam pegar carona e os alunos que querem fornecer elas, tornando as viagens mais acessíveis, econômicas e amigáveis ao meio ambiente. Acreditamos que a 
        carona é uma solução inteligente para reduzir o trânsito, economizar dinheiro e, ao mesmo tempo, contribuir para um planeta mais limpo.

    </p>
    <p>
        Equipe Rodízio de Carona:
    </p>

    <ul>
        <li>
            <strong>Lucas do Carmo Ribeiro</strong> - Desenvolvedor
            <br>
            Email: <a href="#">lc9893291@gmail.com</a>
            <br>
            Discord: <a href="#">lucastat</a>
        </li>
        <li>
            <strong>Samuel Abreu Sales</strong> - Desenvolvedor
            <br>
            Email: <a href="#">samueltonis10@gmail.com</a>
            <br>
            Discord: <a href="#">loiro5638</a>
        </li>
    </ul>

</div>

<footer class="bg-dark text-light p-3 fixed-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; 2023 Rodízio de Carona</p>
            </div>
            <div class="col-md-6 text-end">
                <p><a href="#">Política de Privacidade</a> | <a href="#">Termos de Serviço</a></p>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
