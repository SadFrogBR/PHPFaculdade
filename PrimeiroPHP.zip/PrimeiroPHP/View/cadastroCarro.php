<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Dados do Carro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#"> Rodízio de carona</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../View/login.html">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container" style="margin-bottom: 100px;">
        <h1>Formulário de Dados do Carro</h1>
        <form action="../Controller/CarroController.php" method="post">
            <div class="mb-3">
                <label for="marca" class="form-label">Marca do Carro</label>
                <input type="text" name="marca" class="form-control" id="marca" placeholder="Digite a marca">
            </div>
            <div class="mb-3">
                <label for="modelo" class="form-label">Modelo do Carro</label>
                <input type="text" name="modelo" class="form-control" id="modelo" placeholder="Digite o modelo">
            </div>
            <div class="mb-3">
                <label for="ano" class="form-label">Ano do Carro</label>
                <input type="number" name="ano" class="form-control" id="ano" placeholder="Digite o ano">
            </div>
            <div class="mb-3">
                <label for="cor" class="form-label">Cor do Carro</label>
                <input type="text" name="cor" class="form-control" id="cor" placeholder="Digite a cor">
            </div>
            <div class="mb-3">
                <label for="lugares" class="form-label">Quantidade de Lugares</label>
                <input type="number" name="quantidadeLugares" class="form-control" id="lugares" placeholder="Digite a quantidade de lugares">
            </div>
            <div class="mb-3">
                <label for="consumo" class="form-label">Consumo de Combustível (km/l)</label>
                <input type="number" name="consumoKm" step="0.01" class="form-control" id="consumo" placeholder="Digite o consumo em km/l">
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
    
    <footer class="bg-dark text-light p-3 fixed-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2023 Rodízio de Carona</p>
                </div>
                <div class="col-md-6 text-end">
                    <p><a href="#">Política de Privacidade</a> | <a href="#">Termos de Serviço</a></p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
