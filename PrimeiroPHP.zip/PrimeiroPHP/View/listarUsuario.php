
<?php
  session_start();
  include_once('../Controller/ListarUsuarios.php');
  ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Dados de Usuário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="inicial.php">Rodízio de carona</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../View/inicial.php">Página Inicial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/bio.php">Sobre Nós</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="../View/listarUsuario.php">Exibir Usuarios</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    

    <div class="container">
        <div class="row">
            <div class="col">

            </div>
        </div>
    </div>


    <div class="container">
    <h1>Tabela de Dados</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Idade</th>
                <th>CPF</th>
                <th>Editar</th>
                <th>Apagar</th>

             
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dados as $key => $value) { ?>
            <tr>
            <td> <?php echo $value['nome'] ?></td>
            <td> <?php echo $value['idade'] ?></td>
            <td> <?php echo $value['CPF'] ?></td>
			<td> <a class="btn btn-info" href="editarPessoas.php?id=<?php echo $value['id'] ?>">Editar</a> </td>
			<td> <a class="btn btn-danger" href="../Controller/deletarUsuario.php ?id=<?php echo $value['id'] ?>">Apagar</a> </td>

            </tr>
            <?php }?>
            <!-- Você pode adicionar mais linhas com dados aqui -->
        </tbody>
    </table>
</div>



    <footer class="bg-dark text-light p-3 fixed-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                <p>&copy; 2023 Rodízio de carona</p>
                </div>
                <div class="col-md-6 text-end">
                    <p><a href="#">Política de Privacidade</a> | <a href="#">Termos de Serviço</a></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
