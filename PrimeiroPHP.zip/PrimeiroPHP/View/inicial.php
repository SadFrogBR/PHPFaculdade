
<?php
include_once '../Controller/conexao.php';
session_start();

$conexao=conecta();
  $query = "SELECT usuarios.nome AS  nome_usuario,usuarios.id, usuarios.idade,carros.id, usuarios.statusCarro, carros.marca,carros.vagasPreenchidas, carros.modelo, carros.ano, carros.cor, carros.quantidadeLugares,carros.disponibilidade, carros.consumoKm
  FROM usuarios
  INNER JOIN carros ON usuarios.id = carros.usuario_id";


$result = mysqli_query($conexao, $query);
//$dados = mysqli_fetch_assoc($result);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Dados de Usuário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <a class="navbar-brand" href="#">Rodízio de carona</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../View/inicial.php">Página Inicial</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/bio.php">Sobre Nós</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../View/listarUsuario.php">Exibir Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../Controller/deslogar.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
<div class="alert alert-success" role="alert">
  Seja bem vindo ao sistema <?php echo $_SESSION['nome']; ?>
</div>

<div class="container">
    <div class="row">
        <div class="col-12 col-sm-6">
            Viagem Disponiveis <?php echo $_SESSION['nome']; ?> :

            <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Modelo Carro</th>

                    <th>Número de Vagas</th>

                    <th>Entrar</th>

                </tr>
            </thead>
            <tbody>
            
           
          
      
                   
<?php 
while ($row = mysqli_fetch_assoc($result)) {
    ?>
    <tr>
     
    <td><?php echo $row['nome_usuario']; ?> </td>
    <td><?php echo $row['modelo']; ?>   </td>
    <td><?php echo $row['vagasPreenchidas']; ?>/<?php echo $row['quantidadeLugares'] ; ?> </td>
    <?php
    if ($row['disponibilidade']==1) {
        ?>      <td> <a class="btn btn-success" href="../Controller/entrarCarona.php?id=<?php echo $row['id'] ?>">tenho interesse</a> </td>
            <?php
    }
    else if($row['disponibilidade']==0 ||$row['vagasPreenchidas']== $row['quantidadeLugares'] ){
        ?>      <td><a type="button" class="btn btn-danger">lotado ou indisponivel</a> </td>
        <?php
    }
    ?>

    </tr>  

    
    <?php  
}

?>

                  
            </tbody>
        </table>

        </div>

    
           <?php if ($_SESSION['statusCarro']==1) {    ?>
    <div class="col-12 col-sm-6"> 
   Olá <?php echo $_SESSION['nome']; ?> <br>
   Status atual do seu carro:

<?php if(  $_SESSION['disponibilidade']==1)
   {echo 'disponivel '; } 
   else if( $_SESSION['disponibilidade']==0) {
    echo 'não disponivel ou já esta cheio';
   }
   ?>
<?php $idcarro=$_SESSION['carroID']; ?>
<a class="btn btn-success" href="../Controller/mudarStatusCarro.php?id=<?php echo $idcarro ?>">Mudar Status</a> 

    </div>    
            #
            <?php }?>

            
        
    </div>
</div>




    <footer class="bg-dark text-light p-3 fixed-bottom" style="margin-top: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                <p>&copy; 2023 Rodízio de carona</p>
                </div>
                <div class="col-md-6 text-end">
                    <p><a href="#">Política de Privacidade</a> | <a href="#">Termos de Serviço</a></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
