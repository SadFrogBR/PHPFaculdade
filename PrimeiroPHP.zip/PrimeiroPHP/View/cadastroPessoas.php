<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Dados de Usuário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Rodízio de carona</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="login.html">Login</a>
                    </li>
               
                 
                 
                </ul>
            </div>
        </div>
    </nav>
    <div class="container  p-3" style="margin-bottom: 100px;">
        <h1>Cadastro de Usuário</h1>
        <form action="../Controller/UsuarioController.php" method="post">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" name="nome" class="form-control" id="nome" placeholder="Digite o nome" required>
            </div>
            <div class="mb-3">
                <label for="idade" class="form-label">Idade</label>
                <input type="number" name="idade" class="form-control" id="idade" placeholder="Digite a idade" required>
            </div>
            <div class="mb-3">
                <label for="cpf" class="form-label">CPF</label>
                <input type="text" name="CPF" class="form-control" id="cpf" placeholder="Digite o CPF" required>
            </div>

            <div class="mb-3">
                <label for="cpf" class="form-label">Senha</label>
                <input type="password" name="senha" class="form-control" id="senha" placeholder="Digite a senha" required>
            </div>

            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Descreva sobre você</label>
                <textarea class="form-control" name="descricao" id="exampleFormControlTextarea1" rows="5"></textarea>
            </div>
            <div class="mb-3">
                <label for="turno" class="form-label">Turno de Estudo</label>
                <select class="form-select" name="periodo" id="turno" required>
                    <option value="">Selecione o turno</option>
                    <option value="Manhã">Manhã</option>
                    <option value="Tarde">Tarde</option>
                    <option value="Noite">Noite</option>
                </select>
            </div>
            <label class="form-check-label" for="exampleRadios1">
               Você está interessado em fornecer carona?
             </label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="statusCarro" id="exampleRadios1" value="1" >
                <label class="form-check-label" for="exampleRadios1">
              Sim
                </label>
            </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="statusCarro" id="exampleRadios2" value="0" checked>
                <label class="form-check-label" for="exampleRadios2">
               Não
                </label>
              </div>

              
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>

    <footer class="bg-dark text-light ">
        <div class="container ">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2023 Rodízio de Carona</p>
                </div>
                <div class="col-md-6 text-end">
                    <p><a href="#">Política de Privacidade</a> | <a href="#">Termos de Serviço</a></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
