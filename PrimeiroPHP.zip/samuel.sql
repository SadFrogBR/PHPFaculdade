-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 31/10/2023 às 00:29
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `samuel`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `carros`
--

CREATE TABLE `carros` (
  `id` int(11) NOT NULL,
  `marca` varchar(255) DEFAULT NULL,
  `modelo` varchar(255) DEFAULT NULL,
  `ano` int(11) DEFAULT NULL,
  `cor` varchar(255) DEFAULT NULL,
  `quantidadeLugares` int(11) DEFAULT NULL,
  `consumoKm` decimal(5,2) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `disponibilidade` int(11) DEFAULT NULL,
  `vagasPreenchidas` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `carros`
--

INSERT INTO `carros` (`id`, `marca`, `modelo`, `ano`, `cor`, `quantidadeLugares`, `consumoKm`, `usuario_id`, `disponibilidade`, `vagasPreenchidas`) VALUES
(8, 'HELIX', 'CAMARO', 2013, 'PRETO', 6, 15.00, 35, 1, 2),
(9, 'HELIX', 'CAMARO11', 20131, 'PRETO1', 61, 15.00, 36, 0, 61),
(10, 'xevrolet', 'fiesta', 2012, 'branco', 4, 12.00, 41, 0, 4),
(11, 'sam', 'sam', 1, 'sam', 2, 12.00, 44, 1, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `CPF` varchar(11) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `periodo` varchar(255) DEFAULT NULL,
  `descricao` varchar(500) NOT NULL,
  `statusCarro` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `idade`, `CPF`, `senha`, `periodo`, `descricao`, `statusCarro`) VALUES
(35, '1', 1, '1', '1', 'Manhã', 'xvxcvxcv', '1'),
(36, '2', 2, '2', '2', 'Manhã', '2', '1'),
(37, 'jj', 100, '97678856', '123', 'Tarde', 'fudido', '0'),
(38, 'jj', 100, '97678856', '123', 'Tarde', 'fudido', '0'),
(39, 'll', 14, '11', '11', 'Tarde', 'gvvgjvgh', '0'),
(40, 'samuel', 18, '08586417122', '123', 'Noite', 'sou mono aatrox', '0'),
(41, 'sandro', 12, '098', '123', 'Noite', 'leonardo', '1'),
(42, 'Samuel Abreu', 234, '123', '123', 'Manhã', '222', '1'),
(43, '2', 2, '098', '123', 'Noite', '2', '1'),
(44, 'marcio', 20, '345', '345', 'Manhã', 'eo', '1'),
(45, 'leo', 12, '666', '666', 'Noite', 'oi', '1');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `carros`
--
ALTER TABLE `carros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `carros`
--
ALTER TABLE `carros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `carros`
--
ALTER TABLE `carros`
  ADD CONSTRAINT `carros_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
